import { Component } from '@angular/core';

@Component({
  selector: 'app-furnishing',
  templateUrl: './furnishing.component.html',
  styleUrl: './furnishing.component.css'
})
export class FurnishingComponent {

}
