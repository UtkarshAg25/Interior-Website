import {
  HttpClient,
  HttpErrorResponse,
  HttpHeaders,
} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs';
import { config } from '../config/config';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  protected _isLoggedIn = false;
  public user = new BehaviorSubject<{ role?: string }>({});

  public set isLoggedIn(value: boolean) {
    this._isLoggedIn = value;
  }

  public get isLoggedIn() {
    return this._isLoggedIn;
  }

  constructor(private httpClient: HttpClient, private router: Router) {}

  async login(user: { username: string; password: string }) {
    console.log('user in service file',user)
    const promise = new Promise<any>((resolve: Function, reject: Function) => {
      this.httpClient
        .post<any>(config.serverAddress + 'login', user)
        .subscribe({
          next: (res: any) => {
            if (res.status === 200 && res.token) {
              this.setSession(res.token);
              this.setUserDetails(res?.result);
              this.isLoggedIn = true;
            }
            resolve(res);
          },
          error: (err: HttpErrorResponse) => {
            reject(err);
          },
          complete: () => {
            // this.toastService.show('success', 'Success', 'Login successful');
          },
        });
    });
    return promise;
  }

  private setSession(access_token: string) {
    localStorage.setItem('access_token', access_token);
  }

  private setUserDetails(user: any) {
    localStorage.setItem('user_name', user.userName);
    localStorage.setItem('id', user.userId);
    localStorage.setItem('role', user.role);
  }

  isUserAuthenticated() {
    return localStorage.getItem('access_token') ? true : false;
  }


  logout() {
    this.isLoggedIn = false;
    this.router.navigate(['login']);
    localStorage.clear();
  }

  _construtHttpOptions() {
    return {
      Headers: new HttpHeaders({
        'Content- Type': 'application/json',
      }),
    };
  }
}
