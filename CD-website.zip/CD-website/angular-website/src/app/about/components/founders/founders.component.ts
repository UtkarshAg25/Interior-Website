import { Component } from '@angular/core';

@Component({
  selector: 'app-founders',
  templateUrl: './founders.component.html',
  styleUrl: './founders.component.css'
})
export class FoundersComponent {

}
