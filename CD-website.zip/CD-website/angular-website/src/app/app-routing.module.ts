import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ArchitectureComponent } from './our-services/component/architecture/architecture.component';

const routes: Routes = [
  {
    path: '',
    loadChildren: () => import('./dashboard/dashboard.module').then((m) => m.DashboardModule)
  },
  {
    path: 'dashboard',
    loadChildren: () => import('./dashboard/dashboard.module').then((m) => m.DashboardModule)
  },
  {
    path: 'services',
    loadChildren: () => import('./our-services/our-services.module').then((m)=> m.OurServicesModule)
  },
  {
    path: 'about',
    loadChildren: () => import('./about/about.module').then((m)=> m.AboutModule)
  }
  // {
  //   path: 'services',
  //   component: DummyComponent
  // },
  // {
  //   path: '**',
  //   component: ArchitectureComponent
  // }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
